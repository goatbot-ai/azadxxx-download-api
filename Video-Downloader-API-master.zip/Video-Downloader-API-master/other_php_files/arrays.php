<?php

$supported_hosts = [
	'facebook.com',
	'www.facebook.com',
	'm.facebook.com',
	'fb.com',
	'www.fb.com',
	'www.fb.watch',
	'fb.watch',
	'm.fb.watch',

	'www.instagram.com',
	'instagram.com',

	'www.twitter.com',
	'twitter.com',
	'm.twitter.com',
	'mobile.twitter.com',

	'www.dailymotion.com',
	'dailymotion.com',

	'www.vimeo.com',
	'vimeo.com',
];

$facebookHosts = [
	'facebook.com',
	'www.facebook.com',
	'm.facebook.com',
	'fb.com',
	'www.fb.com',
	'www.fb.watch',
	'fb.watch',
	'm.fb.watch',
];

$instagramHosts = [
	'www.instagram.com',
	'instagram.com',
];

$twitterHosts = [
	'www.twitter.com',
	'twitter.com',
	'm.twitter.com',
	'mobile.twitter.com',
];

$dailymotionHosts = [
	'www.dailymotion.com',
	'dailymotion.com',
];

$vimeoHosts = [
	'www.vimeo.com',
	'vimeo.com',
];